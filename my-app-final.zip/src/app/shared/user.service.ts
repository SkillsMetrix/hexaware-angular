import { Injectable } from '@angular/core';
import { User } from './models/User.model';
import { UserForm } from './models/UserForm.model';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  userData: UserForm[] = [];

  loadUsers(): User[] {
    return [
      { id: 101, name: 'sumit', email: 'sumit@mail.com' },
      { id: 102, name: 'suman', email: 'suman@mail.com' },
    ];
  }

  constructor(private http: HttpClient) {}

  addUserTODB(data: UserForm) {
    this.http.post('http://localhost:3000/users', data).subscribe((res) => {
      console.log(res);
    });
  }

  loadUsersFromDB():Observable<any>{
   return this.http.get('http://localhost:3000/users');
   
}
deleteUserFromDB(id:string):Observable<any>{
 return this.http.delete(`http://localhost:3000/users/${id}`);
}
}