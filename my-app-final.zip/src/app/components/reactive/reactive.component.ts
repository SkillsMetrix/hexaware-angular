import { Component } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../shared/user.service';

@Component({
  selector: 'app-reactive',
  templateUrl: './reactive.component.html',
  styleUrl: './reactive.component.css',
})
export class ReactiveComponent {
  regForm: FormGroup;
  constructor(private fb: FormBuilder,private us:UserService) {
    this.regForm = this.fb.group({
      uname: ['', [Validators.required]],
      email: ['', [Validators.required, this.emailDomainValidator]],
      pass: ['', [Validators.required, Validators.minLength(6)]],
      state: [''],
    });
    this.loadUsers()
  }

  state = ['MH', 'KAR', 'TN', 'TS'];

  addUser() {
   
    this.us.addUserTODB(this.regForm.value)
    alert('user added')
    this.loadUsers()
  }
  emailDomainValidator(control:FormControl){
    let email= control.value
    if(email && email.indexOf('@') != -1){
      let [prefix,domain]=email.split('@')
      
        if(domain !=='hexaware.com'){
        return {
          emailDomain:{
            main:domain
          }
        }
      }
    }
    return null
  }
users:any[]=[]
  loadUsers(){
    this.us.loadUsersFromDB().subscribe((res)=>{
      this.users=res
    })
  }
deleteUser(id:string){
      this.us.deleteUserFromDB(id).subscribe((res)=>{
        console.log('deleted' ,res);
        this.loadUsers()
        
      })
}
}
