import { Component } from '@angular/core';
import { NgForm } from '@angular/forms';
import { UserService } from '../../shared/user.service';

@Component({
  selector: 'app-template',
  templateUrl: './template.component.html',
  styleUrl: './template.component.css'
})
export class TemplateComponent {

  state=['MH','KAR','TN','TS']
  addUser(nf:NgForm){
    this.us.addUserTODB(nf.value)
    
  }
  constructor(private us:UserService){}

}
