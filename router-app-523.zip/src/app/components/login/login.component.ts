import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../shared/user.service';
import { Router } from '@angular/router';
import { UserGuardService } from '../../shared/user-guard.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  regForm: FormGroup;
  constructor(private fb: FormBuilder, private us: UserService,private ug:UserGuardService,
    private route:Router
  ) {
    this.regForm = this.fb.group({
      uname: ['', [Validators.required]],
      pass: ['', [Validators.required, Validators.minLength(6)]],

    });}

    login(){
    this.us.loginUser(this.regForm.value).subscribe(user =>{
      if(user){
        alert('login successfull')
        this.ug.isAllowed=true
        this.route.navigateByUrl('/userdetails')


      }else{
        alert('UnAuthorized ....!')
      }
    })
      
    }
}
