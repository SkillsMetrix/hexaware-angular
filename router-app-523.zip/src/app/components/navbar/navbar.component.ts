import { Component } from '@angular/core';
import { UserGuardService } from '../../shared/user-guard.service';

@Component({
  selector: 'app-navbar',
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {

  constructor(public ug:UserGuardService){}

}
