import { Injectable } from '@angular/core';
import { UserForm } from './models/UserForm.model';
import { HttpClient } from '@angular/common/http';
import { map, Observable } from 'rxjs';
import { UserGuardService } from './user-guard.service';
import { Router } from '@angular/router';

@Injectable({
  providedIn: 'root',
})
export class UserService {

  private baseURL = 'http://localhost:3000/users'
  constructor(private http: HttpClient, private ug: UserGuardService, private route: Router) { }

  addUserTODB(data: UserForm) {
    this.http.post(this.baseURL, data).subscribe((res) => {
      console.log(res);
    });
  }

  loadUsersFromDB(): Observable<any> {
    return this.http.get(this.baseURL);

  }
  deleteUserFromDB(id: string): Observable<any> {
    return this.http.delete(`${this.baseURL}/${id}`);
  }

  logout() {
    this.ug.isAllowed = false
    this.route.navigateByUrl('/login')
  }

  loginUser(data: any): Observable<any> {
    const url = `${this.baseURL}?uname=${data.uname}&pass=${data.pass}`
    return this.http.get<any[]>(url).pipe(
      map(users => users.length ? users[0] : null)
    )
  }
}