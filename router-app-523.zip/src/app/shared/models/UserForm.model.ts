
export interface UserForm{
    
    uname:string
    email:string
    password:string
    state:string
}