import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { LoginComponent } from './components/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { UserdetailsComponent } from './components/userdetails/userdetails.component';
import { PortfolioComponent } from './components/portfolio/portfolio.component';
import { UserGuardService } from './shared/user-guard.service';
import { EmpComponent } from './components/emp/emp.component';
import { CompComponent } from './components/comp/comp.component';

const routes: Routes = [
  {path:'login',component:LoginComponent},
    {path:'register',component:RegisterComponent},
        {path:'userdetails',component:UserdetailsComponent,canActivate:[UserGuardService]},

            {path:'portfolio',component:PortfolioComponent,
              children:[
                {path:'emp',component:EmpComponent},
                {path:'comp',component:CompComponent}
              ]
            },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
