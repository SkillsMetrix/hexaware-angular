import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CartService {

  public CartItemList:any=[]
  public productList= new BehaviorSubject<any>([])

  getProducts(){
    return this.productList.asObservable()
  }
  setProducts(product:any){
    this.CartItemList.push(...product)
    this.productList.next(product)
  }
  addToCart(product : any){
    this.CartItemList.push(product)
    this.productList.next(this.CartItemList)
    this.getTotalPrice()
    console.log(this.CartItemList);
    

  }
  getTotalPrice():number{
    let grandTotal=0
    this.CartItemList.map((a:any) =>{
      grandTotal +=a.total
    })
    return grandTotal
  }

  
}
