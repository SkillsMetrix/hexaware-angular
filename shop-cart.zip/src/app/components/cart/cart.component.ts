import { Component } from '@angular/core';
import { CartService } from '../../shared/services/cart.service';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrl: './cart.component.css'
})
export class CartComponent {
  public products: any = []
  public grandTotal !: number
  constructor(private cs: CartService) {
    this.cs.getProducts()
      .subscribe(res => {
        this.products = res
        this.grandTotal = this.cs.getTotalPrice()
      })
  }

}
