import { Component } from '@angular/core';
import { CartService } from '../../shared/services/cart.service';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent {
public totalItems:number=0
  constructor(private cs:CartService){
    this.cs.getProducts().subscribe((res)=>{
this.totalItems=res.length
    })
  }

}
