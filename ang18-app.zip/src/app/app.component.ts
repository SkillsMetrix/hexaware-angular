import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { MainappComponent } from "./components/mainapp/mainapp.component";

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, MainappComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'ang18-app';
}
