import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ColorChanger } from '../../shared/ColorChanger.directive';

@Component({
  selector: 'app-mainapp',
  standalone: true,
  imports: [FormsModule,ColorChanger],
  templateUrl: './mainapp.component.html',
  styleUrl: './mainapp.component.css'
})
export class MainappComponent {

  city='NY'

}
