import { Directive, ElementRef, Renderer2 } from "@angular/core";

@Directive({
    selector:'[cc]',
    standalone:true
})
export class ColorChanger{
    constructor(private ren:Renderer2,private er:ElementRef){

        this.ren.setStyle(this.er.nativeElement,'backgroundColor','pink')

    }
}