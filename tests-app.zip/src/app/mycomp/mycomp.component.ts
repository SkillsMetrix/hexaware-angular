import { Component } from '@angular/core';

@Component({
  selector: 'app-mycomp',
  templateUrl: './mycomp.component.html',
  styleUrl: './mycomp.component.css'
})
export class MycompComponent {
  username='admin'
  users:{name:string}[]=[]
  data='welcome to our app'

}
