import { ReversePipe } from "./reverse.pipe"


describe('test pipe app',()=>{
    it('should return reverse',()=>{
        let reverse= new ReversePipe()
        expect(reverse.transform('hello')).toEqual('olle')
    })
})