import { Pipe, PipeTransform } from "@angular/core";


@Pipe({
    name:'caps'
})

export class CapsApp implements PipeTransform{
    transform(value: string) {
        return value.split(' ')
        .map(data => data[0].toUpperCase()+ data.slice(1).toLowerCase())
        .join(' ')
    }
}