import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { UserService } from '../../shared/user.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  regForm: FormGroup;
  constructor(private fb: FormBuilder, private us: UserService) {
    this.regForm = this.fb.group({
      uname: ['', [Validators.required]],
      pass: ['', [Validators.required, Validators.minLength(6)]],

    });}

    login(){
    this.us.loginService()
      
    }
}
