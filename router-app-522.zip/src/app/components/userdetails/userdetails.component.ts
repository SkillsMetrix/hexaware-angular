import { Component } from '@angular/core';
import { UserService } from '../../shared/user.service';

@Component({
  selector: 'app-userdetails',
  templateUrl: './userdetails.component.html',
  styleUrl: './userdetails.component.css'
})
export class UserdetailsComponent {

  constructor(private us:UserService){
    this.loadUsers()
  }

  users:any[]=[]
  loadUsers(){
    this.us.loadUsersFromDB().subscribe((res)=>{
      this.users=res
    })
  }
deleteUser(id:string){
      this.us.deleteUserFromDB(id).subscribe((res)=>{
        console.log('deleted' ,res);
        this.loadUsers()
        
      })
}
logout(){
  this.us.logout()
}

}
