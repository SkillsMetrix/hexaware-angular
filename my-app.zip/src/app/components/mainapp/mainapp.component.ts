import { Component, Input } from '@angular/core';
import { UserService } from '../../shared/user.service';
import { User } from '../../shared/models/User.model';

@Component({
  selector: 'app-mainapp',
  templateUrl: './mainapp.component.html',
  styleUrl: './mainapp.component.css'
})
export class MainappComponent {

  constructor(private us:UserService,){
    this.userData=this.us.loadUsers()
  }
@Input()
  username='Amarjeet'
  city='pune'
  state='MH'
 
  userData:User[]=[]
  
  addUser(){
    alert('user added..!')
  }
}
