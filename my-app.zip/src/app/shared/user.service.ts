import { Injectable } from '@angular/core';
import { User } from './models/User.model';
import { UserForm } from './models/UserForm.model';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  userData:UserForm[]=[]

  loadUsers(): User[] {
    return [
      { id: 101, name: 'sumit', email: 'sumit@mail.com' },
      { id: 102, name: 'suman', email: 'suman@mail.com' }
    ]
  }

  constructor() { }

  addUserTODB(data:UserForm){
    this.userData.push(data)
    console.log(this.userData);
    
   
  }
}
